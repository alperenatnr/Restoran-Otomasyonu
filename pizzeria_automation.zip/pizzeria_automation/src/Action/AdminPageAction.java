
package Action;

import gui.AdminPage;
import gui.GUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import Entity.*;

public class AdminPageAction implements ActionListener{
    private AdminPage ap;
    Admin a;
    
    public AdminPageAction(AdminPage ap) {
        this.ap=ap;
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        
        if ( e.getSource()== ap.getOpen())
        {
            JOptionPane.showMessageDialog(null,"pizzaria açıldı");
            
        }
        
        else if (e.getSource()== ap.getClose())
        {
            JOptionPane.showMessageDialog(null,"pizzaria kapatıldı.");
            try {
                GUI g = new GUI();
            } catch (IOException ex) {
                Logger.getLogger(AdminLoginAction.class.getName()).log(Level.SEVERE,null,ex);
            }
        }
        else if(e.getSource() == ap.getAdd())
        {
            if(ap.getPerEkleText().getText().length() == 0 ||ap.getPerEkleText2().getText().length() == 0 || ap.getPerEkleText3().getText().length() == 0){
                JOptionPane.showMessageDialog(null,"Tüm Alanları Doldurunuz");
            }
            else{
                //boolean control = a.PersonelEkle(1,ap.getPerEkleText().getText(), ap.getPerEkleText2().getText(),  ap.getPerEkleText3().getText());
                //if(control){
                    //JOptionPane.showConfirmDialog(null, "Personel başarıyla eklendi");
                    //ap.getPerEkleText().setText(null);
                    //ap.getPerEkleText2().setText(null);
                    //ap.getPerEkleText3().setText(null);
                    //ap.updatepersonelModel();
                //}
            }
        }
    }

    
    
}
