
package Action;

import gui.AdminLogin;
import gui.AdminPage;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class AdminLoginAction implements ActionListener{
    private AdminLogin a;
    
    public AdminLoginAction(AdminLogin a) {
        this.a=a;
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        
        if (e.getSource() == a.getLogin_button())
        {
            if(a.getA_Nick().getText().length() == 0 || a.getA_pass().getText().length() == 0){
                JOptionPane.showMessageDialog(null, "Lütfen tüm alanları doldurunuz");
            }
            
            
            
            
            try { 
                AdminPage ap = new AdminPage();
                a.dispose();
            } catch (IOException ex) {
                Logger.getLogger(AdminLoginAction.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        
        
        
    }

    

    
    
}
