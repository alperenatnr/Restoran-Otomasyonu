package Action;

import gui.AdminLogin;
import gui.GUI;
import gui.Tables;
import gui.UserPage;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class gui_action implements ActionListener {

    private GUI g;

    public gui_action(GUI g) {
        this.g = g;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == g.getAdmin_button()) {
            try {
                AdminLogin a = new AdminLogin();
                g.dispose();
            } catch (IOException ex) {
                Logger.getLogger(gui_action.class.getName()).log(Level.SEVERE, null, ex);
            }

        } else if (e.getSource() == g.getUser_button()) {
            try {
                Tables t = new Tables();
                g.dispose();
            } catch (IOException ex) {
                Logger.getLogger(gui_action.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

}
