package Action;

import gui.UserPage;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UserOpenPageAction implements ActionListener {

    private UserPage up;

    public UserOpenPageAction(UserPage up) {
        this.up = up;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == up.getB2()) {

        } else if (e.getSource() == up.getB3()) {

        
    }

    }
}
