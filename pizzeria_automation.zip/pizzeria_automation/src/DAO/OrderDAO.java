
package DAO;

import Entity.Order;
import File.FileOp;
import java.io.IOException;



public class OrderDAO extends AbstractDAO<Order> {
    @Override
    public void insert(Order entity) throws IOException {
        FileOp f = new FileOp();
        f.yazdir(entity.toString());
    }
}
