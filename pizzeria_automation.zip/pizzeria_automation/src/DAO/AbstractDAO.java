
package DAO;

import File.FileOp;
import java.io.IOException;

public abstract class AbstractDAO<T> {
    public void insert (T entity) throws IOException{
        FileOp ds = new FileOp();
        ds.yazdir(entity.toString());
    }
    
    
}
