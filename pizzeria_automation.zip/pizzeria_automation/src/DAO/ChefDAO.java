
package DAO;

import Entity.chef;
import File.FileOp;
import java.io.IOException;

public class ChefDAO extends AbstractDAO<chef> {
    @Override
    public void insert(chef entity) throws IOException {
        FileOp f = new FileOp();
        f.yazdir(entity.toString());
    }
}
