
package DAO;

import Entity.Personel;
import File.FileOp;
import java.io.IOException;



public class PersonelDAO extends AbstractDAO<Personel> {
    @Override
    public void insert(Personel entity) throws IOException {
        FileOp f = new FileOp();
        f.yazdir(entity.toString());
    }
}
