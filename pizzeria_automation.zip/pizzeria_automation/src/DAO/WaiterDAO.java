
package DAO;

import Entity.waiter;
import File.FileOp;
import java.io.IOException;


public class WaiterDAO extends AbstractDAO<waiter> {
    @Override
    public void insert(waiter entity) throws IOException {
        FileOp f = new FileOp();
        f.yazdir(entity.toString());
    }
}
