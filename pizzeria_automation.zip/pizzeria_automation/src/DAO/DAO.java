
package DAO;

import java.util.List;



public interface DAO <T>{
    public void insert( T Entity);
    public List<T> getList();
    
}
