
package DAO;

import Entity.Admin;
import File.FileOp;
import java.io.IOException;

public class AdminDAO extends AbstractDAO<Admin> {
    @Override
    public void insert(Admin entity) throws IOException {
        FileOp f = new FileOp();
        f.yazdir(entity.toString());
    }
}
