
package Controller;

import DAO.AdminDAO;
import Entity.Admin;
import java.io.IOException;
import java.util.List;



public class AdminController {
    
    
    private Admin entity;
    private List<Admin> list;
    private AdminDAO dao;
    
    
    public void create(long Id) throws IOException{
        Admin newAdmin = this.getEntity();
        newAdmin.setId(Id);
        
        
        
    }

    public Admin getEntity() {
        if(this.entity == null){
            entity = new Admin();
        }
        return entity;
    }

    public void setEntity(Admin entity) {
        this.entity = entity;
    }

    public List<Admin> getList() {
        return list;
    }

    public void setList(List<Admin> list) {
        this.list = list;
    }

    public AdminDAO getDao() {
        if(this.dao == null){
            dao = new AdminDAO();
        }
        return dao;
    }

    public void setDao(AdminDAO dao) {
        this.dao = dao;
    }
}
