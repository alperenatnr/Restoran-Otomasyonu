package Controller;

import DAO.PersonelDAO;
import Entity.Personel;
import java.io.IOException;
import java.util.List;

public class PersonelController {

    private Personel entity;
    private List<Personel> list;
    private PersonelDAO dao;
    
    
    public void create(long Id) throws IOException{
        Personel newPersonel = this.getEntity();     
    }

    public Personel getEntity() {
        if(this.entity == null){
            entity = new Personel();
        }
        return entity;
    }

    public void setEntity(Personel entity) {
        this.entity = entity;
    }

    public List<Personel> getList() {
        return list;
    }

    public void setList(List<Personel> list) {
        this.list = list;
    }

    public PersonelDAO getDao() {
        if(this.dao == null){
            dao = new PersonelDAO();
        }
        return dao;
    }

    public void setDao(PersonelDAO dao) {
        this.dao = dao;
    }
    
}
