
package Controller;

import DAO.OrderDAO;
import Entity.Order;
import java.io.IOException;
import java.util.List;

public class OrderController {
    
    
    
     private Order entity;
    private List<Order> list;
    private OrderDAO dao;
    
    
     public void create(String name,int Price) throws IOException{
        Order newOrder = this.getEntity();
        newOrder.AddMenuItem(name,Price);
        
        
        
    }
         public Order getEntity() {
        if(this.entity == null){
            entity = new Order() {};
        }
        return entity;
    }

    public void setEntity(Order entity) {
        this.entity = entity;
    }

    public List<Order> getList() {
        return list;
    }

    public void setList(List<Order> list) {
        this.list = list;
    }

    public OrderDAO getDao() {
        if(this.dao == null){
            dao = new OrderDAO();
        }
        return dao;
    }

    public void setDao(OrderDAO dao) {
        this.dao = dao;
    }
}
