
package Menu;

public abstract class Order {
    private int OrderId;

    
    
    
    
    public void AddMenuItem(){
        
    }
    public void RemoveMenuItem(){
        
    }
    public void OnlineOrder(){
        
    }
    
    
    
    //getter setter    
    public int getOrderId() {
        return OrderId;
    }

    public void setOrderId(int OrderId) {
        this.OrderId = OrderId;
    }
}
