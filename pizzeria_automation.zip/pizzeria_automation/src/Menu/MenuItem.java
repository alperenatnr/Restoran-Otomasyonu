
package Menu;

public class MenuItem {
    private int MenuItemId;
    private int price;
    private String Title;
    private String description;
    
    
    
    //getter setter
    public int getMenuItemId() {
        return MenuItemId;
    }

    public void setMenuItemId(int MenuItemId) {
        this.MenuItemId = MenuItemId;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String Title) {
        this.Title = Title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
    
    
    
    
    
    
}
