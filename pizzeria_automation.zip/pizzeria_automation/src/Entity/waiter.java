
package Entity;


public class waiter extends Personel {
    private Long id;
    private String name;
    private int Salary;
    private String type;
    public String MakeAnOrder(){
        System.out.println("garson siparişi aldı");
        return null;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
}
