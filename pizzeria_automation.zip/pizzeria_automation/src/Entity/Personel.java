package Entity;

public class Personel {

    private Long id;
    private String name;
    
    
    public Personel() {
    }
    
}
