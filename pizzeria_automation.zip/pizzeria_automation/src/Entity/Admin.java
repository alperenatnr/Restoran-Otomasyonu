package Entity;

import java.util.ArrayList;


public class Admin {
    private Long id;
    private String name;
    

    public Admin() {
    }

    public ArrayList<Personel> getPersonelList(){
        ArrayList<Personel> list = new ArrayList();
        Personel obj;
        //dosya işlemleri
        return list;
    }
    
    public boolean PersonelEkle(Long id,String name,int Salary,String type){
        return true;
    }
    
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    
    
}
