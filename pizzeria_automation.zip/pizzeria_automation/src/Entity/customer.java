
package Entity;

public class customer extends Personel {
    private Long id;
    private String name;
    private int NumberOfCustomer;
    private String address;

    

    
    
    public void CancelOrder(){
        
    }
    public int OrderCustomization(){// burda işimiz sadece sayılarla olacak menü item no ile degişecek sipariş
        
        
        return 0;
        
    }
    
    //getter setter methotları
    public int getNumberOfCustomer() {
        return NumberOfCustomer;
    }

    public void setNumberOfCustomer(int NumberOfCustomer) {
        this.NumberOfCustomer = NumberOfCustomer;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
    
}
