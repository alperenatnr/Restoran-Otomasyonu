
package Entity;

public class chef extends Personel {
    private Long id;
    private String name;
    private int Salary;
    private String type;
    
    public String TakeAnOrder(){
        System.out.println("şef siparişi aldı");
        return null;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
}
