package gui;

import Action.gui_action;
import java.awt.*;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;

public class GUI extends JFrame {

    private JButton Admin_button, User_button;
    private JLabel baslik;

    public GUI() throws IOException {
        initJFrame();
    }

    private void initJFrame() throws IOException {
        add(initPanel());
        setTitle("Restoran Otomasyonu");
        setIconImage(ImageIO.read(new File("res/Icon.png")));
        setSize(500, 400);
        setLocationRelativeTo(null);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }

    private JPanel initPanel() {
        JPanel GUI = new JPanel();
        GUI.setLayout(null);

        GUI.add(getAdmin_button());
        GUI.add(getBaslik());
        GUI.add(getUser_button());

        return GUI;
    }

    public JButton getAdmin_button() {
        if (Admin_button == null) {
            this.Admin_button = new JButton("Yönetim");
            Admin_button.setBounds(150, 170, 170, 40);
            Admin_button.addActionListener(new gui_action(this));
        }
        return Admin_button;
    }

    public void setAdmin_button(JButton Admin_button) {
        this.Admin_button = Admin_button;
    }

    public JButton getUser_button() {
        if (User_button == null) {
            this.User_button = new JButton("Restoranı aç");
            User_button.setBounds(150, 230, 170, 40);
            User_button.addActionListener(new gui_action(this));
        }
        return User_button;
    }

    public void setUser_button(JButton User_button) {
        this.User_button = User_button;
    }

    public JLabel getBaslik() {
        if (baslik == null) {
            this.baslik = new JLabel("PIZZA HOUSE");
            baslik.setBounds(130, 50, 280, 50);
            baslik.setFont(new Font("Arial", Font.PLAIN, 35));
        }
        return baslik;
    }

    public void setBaslik(JLabel baslik) {
        this.baslik = baslik;
    }

}
