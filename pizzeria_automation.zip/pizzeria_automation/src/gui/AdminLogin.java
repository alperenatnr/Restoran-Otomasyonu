package gui;

import Action.AdminLoginAction;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class AdminLogin extends JFrame {

    private JButton Login_button;
    private JLabel A_nickLabel, A_passLabel, baslik;
    private JPasswordField A_pass;
    private JTextField A_Nick;

    public AdminLogin() throws IOException {
        initJFrame();
    }

    private void initJFrame() throws IOException {
        add(initPanel());
        setTitle("Admin Girişi");
        setIconImage(ImageIO.read(new File("res/Icon.png")));
        setSize(500, 400);
        setLocationRelativeTo(null);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }

    private JPanel initPanel() {
        JPanel AdminLogin = new JPanel();
        AdminLogin.setLayout(null);

        AdminLogin.add(getA_Nick());
        AdminLogin.add(getA_nickLabel());
        AdminLogin.add(getA_pass());
        AdminLogin.add(getA_passLabel());
        AdminLogin.add(getBaslik());
        AdminLogin.add(getLogin_button());

        return AdminLogin;
    }

//        
//        Login_button.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//              String K_adı ="seha";
//              String K_sifre ="1234";
//        
//            if (A_Nick.getText().equals(K_adı)  && A_pass.getText().equals(K_sifre))
//            {
//                JOptionPane.showMessageDialog(null, "giriş başarılı");
//                AdminPage a = null;
//                  try {
//                      a = new AdminPage();
//                  } catch (IOException ex) {
//                      Logger.getLogger(AdminLogin.class.getName()).log(Level.SEVERE, null, ex);
//                  }
//                a.calis();
//                
//            }
//            else
//            {
//                JOptionPane.showMessageDialog(null, "giriş başarısız tekrar deneyiniz");
//            }
//            }
//        });


    public JButton getLogin_button() {
        if (Login_button == null) {
            this.Login_button = new JButton("Giriş Yap:");
            Login_button.setBounds(150, 230, 170, 40);
            Login_button.addActionListener(new AdminLoginAction(this));
        }
        return Login_button;
    }

    public void setLogin_button(JButton Login_button) {
        this.Login_button = Login_button;
    }

    public JLabel getA_nickLabel() {
        if (A_nickLabel == null) {
            this.A_nickLabel = new JLabel("Kullanıcı adı:");
            A_nickLabel.setBounds(150, 110, 150, 20);
        }
        return A_nickLabel;
    }

    public void setA_nickLabel(JLabel A_nickLabel) {
        this.A_nickLabel = A_nickLabel;
    }

    public JLabel getA_passLabel() {
        if (A_passLabel == null) {
            this.A_passLabel = new JLabel("Admin Şifresi:");
            A_passLabel.setBounds(150, 160, 150, 20);
        }
        return A_passLabel;
    }

    public void setA_passLabel(JLabel A_passLabel) {
        this.A_passLabel = A_passLabel;
    }

    public JLabel getBaslik() {
        if (baslik == null) {
            this.baslik = new JLabel("PIZZA HOUSE");
            baslik.setBounds(130, 50, 280, 50);
            baslik.setFont(new Font("Arial", Font.PLAIN, 35));
        }
        return baslik;
    }

    public void setBaslik(JLabel baslik) {
        this.baslik = baslik;
    }

    public JPasswordField getA_pass() {
        if(A_pass == null){
            this.A_pass = new JPasswordField();
            A_pass.setBounds(150, 180, 170, 30);
        }
        return A_pass;
    }

    public void setA_pass(JPasswordField A_pass) {
        this.A_pass = A_pass;
    }

    public JTextField getA_Nick() {
        if(A_Nick == null){
            this.A_Nick = new JTextField();
            A_Nick.setBounds(150, 130, 170, 30);
        }
        return A_Nick;
    }

    public void setA_Nick(JTextField A_Nick) {
        this.A_Nick = A_Nick;
    }

    
}
