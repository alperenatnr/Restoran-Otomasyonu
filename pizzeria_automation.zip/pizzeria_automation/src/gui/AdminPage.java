package gui;

import Action.AdminPageAction;
import Entity.Admin;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class AdminPage extends JFrame {

    private JButton Open, Close,Add;
    private JLabel baslik,NumOFwaiter_Label, NumOFchef_Label, NumOFmenu_Label, allOreders_Label;
    private JTextField menu_addText,perEkleText,perEkleText2,perEkleText3;
    private JTable GarsonEkleCikar;
    private JScrollPane GarsonEkleCikarsp;
    private DefaultTableModel personelModel = null;
    private Object[] personelData = null;
    private JLabel perEkle;
    Admin admin;

    public AdminPage() throws IOException {
        personelModel = new DefaultTableModel();
        Object[] colPersonelName = new Object[4];
        colPersonelName[0] = "ID";
        colPersonelName[1] = "Name";
        colPersonelName[2] = "Salary";
        colPersonelName[3] = "Type";
        personelModel.setColumnIdentifiers(colPersonelName);
        personelData = new Object[4];
       for(int i = 0; i < admin.getPersonelList().size();i++){
            personelData[0] = admin.getPersonelList().get(i).getId();
            personelData[1] = admin.getPersonelList().get(i).getName();
            personelData[2] = admin.getPersonelList().get(i).getSalary();
            personelData[3] = admin.getPersonelList().get(i).getType();
            personelModel.addRow(personelData);
        }
        initJFrame();
    }

    public void updatepersonelModel(){
        DefaultTableModel clearModel = (DefaultTableModel) GarsonEkleCikar.getModel();
        clearModel.setRowCount(0);
        for(int i = 0; i < admin.getPersonelList().size();i++){
            personelData[0] = admin.getPersonelList().get(i).getId();
            personelData[1] = admin.getPersonelList().get(i).getName();
            personelData[2] = admin.getPersonelList().get(i).getSalary();
            personelData[3] = admin.getPersonelList().get(i).getType();
            personelModel.addRow(personelData);
        }
    }
    
    private void initJFrame() throws IOException {
        add(initPanel());
        setTitle("Admin Kontrol Sayfası");
        setIconImage(ImageIO.read(new File("res/Icon.png")));
        setSize(1300, 800);
        setLocationRelativeTo(null);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }

    private JPanel initPanel() {
        JPanel AdminControlPage = new JPanel();
        AdminControlPage.setLayout(null);

        AdminControlPage.add(getAllOreders_Label());
        AdminControlPage.add(getBaslik());
        AdminControlPage.add(getAdd());
        AdminControlPage.add(getPerEkleText());
        AdminControlPage.add(getPerEkleText2());
        AdminControlPage.add(getPerEkleText3());
        
        AdminControlPage.add(getClose());
        AdminControlPage.add(getPerEkle());
        AdminControlPage.add(getGarsonEkleCikarsp());
        AdminControlPage.add(getNumOFchef_Label());
        AdminControlPage.add(getNumOFmenu_Label());
        AdminControlPage.add(getNumOFwaiter_Label());
        AdminControlPage.add(getOpen());

        return AdminControlPage;
    }

    public JLabel getPerEkle() {
        if(perEkle == null){
            this.perEkle = new JLabel("Personel Ekle");
            perEkle.setBounds(320, 150, 100, 20);
        }
        return perEkle;
    }

    public void setPerEkle(JLabel perEkle) {
        this.perEkle = perEkle;
    }

    public JButton getAdd() {
        if(Add == null){
            this.Add = new JButton("Personel Ekle");
            Add.setBounds(320,300,100,30);
        }
        return Add;
    }

    public void setAdd(JButton Add) {
        this.Add = Add;
    }

    public JTextField getPerEkleText() {
        if(perEkleText == null){
            this.perEkleText = new JTextField();
            perEkleText.setBounds(320, 180, 150, 30);
        }
        return perEkleText;
    }

    public void setPerEkleText(JTextField perEkleText) {
        this.perEkleText = perEkleText;
    }

    public JTextField getPerEkleText2() {
        if(perEkleText2 == null){
            this.perEkleText2 = new JTextField();
            perEkleText2.setBounds(320, 220, 150, 30);
        }
        return perEkleText2;
    }

    public void setPerEkleText2(JTextField perEkleText2) {
        this.perEkleText2 = perEkleText2;
    }

    public JTextField getPerEkleText3() {
        if(perEkleText3 == null){
            this.perEkleText3 = new JTextField();
            perEkleText3.setBounds(320, 260, 150, 30);
        }
        return perEkleText3;
    }

    public void setPerEkleText3(JTextField perEkleText3) {
        this.perEkleText3 = perEkleText3;
    }
    
    
    
    public JScrollPane getGarsonEkleCikarsp() {
        if(GarsonEkleCikarsp == null){
            this.GarsonEkleCikarsp = new JScrollPane(getGarsonEkleCikar());
            GarsonEkleCikarsp.setBounds(10, 150, 250, 500);
        }
        return GarsonEkleCikarsp;
    }

    public void setGarsonEkleCikarsp(JScrollPane GarsonEkleCikarsp) {
        this.GarsonEkleCikarsp = GarsonEkleCikarsp;
    }

    
    
    public JTable getGarsonEkleCikar() {
        if(GarsonEkleCikar == null){
            String data[][] = {{"01", "Alperen", "7500","Şef"},
            {"02", "Seha", "5200","Garson"},
            {"03", "Barış", "4800","Garson"}};
            String column[] = {"ID", "Name", "Salary","Type"};
            this.GarsonEkleCikar = new JTable(data, column);
            GarsonEkleCikar.setBounds(10, 100, 250, 500);
            
        }
        return GarsonEkleCikar;
    }

    public void setGarsonEkleCikar(JTable GarsonEkleCikar) {
        this.GarsonEkleCikar = GarsonEkleCikar;
    }

    
    
    public JButton getOpen() {
        if (Open == null) {
            this.Open = new JButton("Restorantı Aç");
            Open.setBounds(800, 500, 250, 100);
            Open.addActionListener(new AdminPageAction(this));
        }
        return Open;
    }

    public void setOpen(JButton Open) {
        this.Open = Open;
    }

    public JButton getClose() {
        if (Close == null) {
            this.Close = new JButton("Restorantı Kapat");
            Close.setBounds(800, 630, 250, 100);
            Close.addActionListener(new AdminPageAction(this));
        }
        return Close;
    }

    public void setClose(JButton Close) {
        this.Close = Close;
    }

    public JLabel getBaslik() {
        if (baslik == null) {
            this.baslik = new JLabel("Admin Kontrol Sayfası");
            baslik.setBounds(450, 50, 340, 50);
            baslik.setFont(new Font("Arial", Font.PLAIN, 35));
        }
        return baslik;
    }

    public void setBaslik(JLabel baslik) {
        this.baslik = baslik;
    }

    public JLabel getNumOFwaiter_Label() {
        if (NumOFwaiter_Label == null) {
            this.NumOFwaiter_Label = new JLabel("Garson sayısı:");
            NumOFwaiter_Label.setBounds(800, 150, 170, 30);
            NumOFwaiter_Label.setFont(new Font("Arial", Font.PLAIN, 18));
        }
        return NumOFwaiter_Label;
    }

    public void setNumOFwaiter_Label(JLabel NumOFwaiter_Label) {
        this.NumOFwaiter_Label = NumOFwaiter_Label;
    }

    public JLabel getNumOFchef_Label() {
        if (NumOFchef_Label == null) {
            this.NumOFchef_Label = new JLabel("Şef sayısı:");
            NumOFchef_Label.setBounds(800, 210, 170, 30);
            NumOFchef_Label.setFont(new Font("Arial", Font.PLAIN, 18));
        }
        return NumOFchef_Label;
    }

    public void setNumOFchef_Label(JLabel NumOFchef_Label) {
        this.NumOFchef_Label = NumOFchef_Label;
    }

    public JLabel getNumOFmenu_Label() {
        if (NumOFmenu_Label == null) {
            this.NumOFmenu_Label = new JLabel("Menü Sayısı:");
            NumOFmenu_Label.setBounds(800, 330, 170, 30);
            NumOFmenu_Label.setFont(new Font("Arial", Font.PLAIN, 18));
        }
        return NumOFmenu_Label;
    }

    public void setNumOFmenu_Label(JLabel NumOFmenu_Label) {
        this.NumOFmenu_Label = NumOFmenu_Label;
    }

    public JLabel getAllOreders_Label() {
        if (allOreders_Label == null) {
            this.allOreders_Label = new JLabel("Toplma Sipariş Sayısı:");
            allOreders_Label.setBounds(800, 390, 200, 30);
            allOreders_Label.setFont(new Font("Arial", Font.PLAIN, 18));
        }
        return allOreders_Label;
    }

    public void setAllOreders_Label(JLabel allOreders_Label) {
        this.allOreders_Label = allOreders_Label;
    }

    public JTextField getMenu_addText() {
        if (menu_addText == null) {
            this.menu_addText = new JTextField();
            menu_addText.setBounds(150, 335, 250, 30);
        }
        return menu_addText;
    }

    public void setMenu_addText(JTextField menu_addText) {
        this.menu_addText = menu_addText;
    }

}
