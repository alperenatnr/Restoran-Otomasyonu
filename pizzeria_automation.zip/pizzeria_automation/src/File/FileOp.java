package File;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FileOp {

    File f = new File("veri.txt");

    public void yazdir(String veri) throws IOException {
        if (!f.exists()) {
            try {
                f.createNewFile();
            } catch (IOException ex) {
                Logger.getLogger(FileOp.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        FileWriter fw = new FileWriter(f, true);
        fw.write(veri + "\n");
        fw.close();

    }

    public void oku() throws FileNotFoundException, IOException {

        List<String> list = new ArrayList<>();
        BufferedReader br = null;
        String line;
        br = new BufferedReader(new FileReader("veri.txt"));

        while ((line = br.readLine()) != null) {
            list.add(line);
             System.out.println(line);
        }

    }
    
    
}
